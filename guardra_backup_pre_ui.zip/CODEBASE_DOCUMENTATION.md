# Guardra Privacy Suite — Complete Codebase Documentation

> **Auto-generated internal documentation. This file is excluded from version control via `.gitignore`.**

---

## 1. Project Overview

**Guardra** is an open-source privacy suite that provides real-time website privacy policy analysis, statutory data deletion request generation, breach monitoring, and tracker blocking. It enforces compliance with three major data protection frameworks:

- **DPDP Act 2023** (India) — Digital Personal Data Protection Act
- **GDPR** (EU) — General Data Protection Regulation, Article 17
- **CCPA / CPRA** (California) — California Consumer Privacy Act

The project is split across two repositories:

| Repository | Purpose | Stack |
|---|---|---|
| **Guardra** (`/home/blue/CIH/Guardra/`) | Frontend SPA + Browser Extension + Backend copy | React/Vite, Tailwind CSS, Chrome MV3 |
| **Guardra-Server** (`/home/blue/CIH/Guardra-Server/`) | Production Backend API | Python 3.11+, FastAPI, SQLite, Pydantic |

---

## 2. Architecture Overview

```mermaid
graph TD
    subgraph "Browser"
        EXT["Guardra Extension - Chrome MV3"]
        POPUP["Extension Popup UI"]
        CS["Content Scripts"]
        DNR["DeclarativeNetRequest Rulesets"]
    end

    subgraph "Web Dashboard"
        FRONTEND["React SPA - Vite + Tailwind"]
    end

    subgraph "Guardra-Server - FastAPI"
        MAIN["main.py - App Entry"]
        R_POLICY["policy.py - /api/policy"]
        R_DELETE["deletion.py - /api/deletion"]
        R_BREACH["breach.py - /api/breach"]
        R_HUB["hub.py - /api/hub"]
        R_ADMIN["admin.py - /api/admin"]
        S_NLP["policy_analyzer.py - NLP Engine"]
        S_DEL["deletion_service.py - PDF Generator"]
        S_BREACH["breach_service.py - HIBP + OSINT"]
        S_COOKIE["cookie_service.py"]
        S_CRAWL["crawler_service.py"]
        DB[("SQLite - guardra.db")]
    end

    FRONTEND -->|REST API| MAIN
    EXT -->|Telemetry + Rating| MAIN
    MAIN --> R_POLICY & R_DELETE & R_BREACH & R_HUB & R_ADMIN
    R_POLICY --> S_NLP --> DB
    R_DELETE --> S_DEL --> DB
    R_BREACH --> S_BREACH
    R_ADMIN --> S_CRAWL & S_COOKIE
    S_COOKIE --> DB
    S_CRAWL --> DB
```

---

## 3. Directory Structure

### Guardra (Frontend + Extension)
```
Guardra/
├── frontend/
│   ├── src/
│   │   ├── App.jsx                    # Root component, tab-based routing
│   │   ├── main.jsx                   # Vite entry point
│   │   ├── index.css                  # Tailwind base + custom styles
│   │   ├── components/
│   │   │   ├── Navbar.jsx             # Top navigation bar with search
│   │   │   └── Sidebar.jsx            # Left sidebar navigation
│   │   ├── pages/
│   │   │   ├── Dashboard.jsx          # Home dashboard with quick stats
│   │   │   ├── PolicyAnalyzer.jsx     # Privacy policy NLP analysis UI
│   │   │   ├── DeletionAssistant.jsx  # Legal erasure request builder
│   │   │   ├── BreachMonitor.jsx      # Password/email breach checker
│   │   │   ├── ControlHub.jsx         # Privacy footprint + platform controls
│   │   │   ├── IdentityWizard.jsx     # Identity compartmentalization guide
│   │   │   ├── EducationHub.jsx       # Privacy education modules
│   │   │   ├── Regulators.jsx         # Regulator escalation templates
│   │   │   └── AdminDashboard.jsx     # Admin portal for site management
│   │   └── services/
│   │       └── api.js                 # API client with offline fallbacks
│   ├── index.html, vite.config.js, tailwind.config.js, package.json
├── extension/
│   ├── manifest.json                  # Chrome MV3 manifest
│   ├── background/service_worker.js   # DNR management, API polling, state
│   ├── content/
│   │   ├── content_script.js          # DOM scanning, cookie clearing
│   │   ├── tracker_defuser.js         # Tracker interception (MAIN world)
│   │   ├── yt_defuser.js             # YouTube-specific defuser
│   │   └── youtube_cosmetics.css      # YouTube ad hiding
│   ├── popup/
│   │   ├── popup.html / popup.js / popup.css
│   ├── rulesets/
│   │   ├── base_rules.json           # Ad-blocking DNR rules
│   │   └── privacy_rules.json        # Tracker-blocking DNR rules
│   └── resources/empty.json, noop.js
├── backend/                           # (Copy of Guardra-Server code)
├── README.md, CREDITS.md, LICENSE, RATING_METHODOLOGY.md
├── run_demo.sh                       # Launch script (backend + frontend)
└── landing.html                      # Static landing page
```

### Guardra-Server (Backend API)
```
Guardra-Server/
├── app/
│   ├── main.py                       # FastAPI app, CORS, startup, root routes
│   ├── database.py                   # SQLite schema, migrations, connection
│   ├── models/schemas.py             # Pydantic request/response models
│   ├── routers/
│   │   ├── policy.py                 # Privacy rating endpoints
│   │   ├── deletion.py               # Data deletion request endpoints
│   │   ├── breach.py                 # Breach monitoring endpoints
│   │   ├── hub.py                    # Privacy hub + telemetry endpoints
│   │   └── admin.py                  # Admin dashboard endpoints
│   ├── services/
│   │   ├── policy_analyzer.py        # NLP scoring engine (832 lines)
│   │   ├── breach_service.py         # HIBP + OSINT breach search
│   │   ├── cookie_service.py         # Cookie classification + rules
│   │   ├── deletion_service.py       # Legal notice + PDF generation
│   │   ├── footprint_service.py      # Privacy footprint calculator
│   │   ├── crawler_service.py        # Automated domain crawler
│   │   └── top_sites_service.py      # Tranco top-5000 pipeline
│   ├── data/                         # JSON data files
│   └── static/                       # HTML pages
├── Dockerfile, docker-compose.yml, requirements.txt, .env.example
```

---

## 4. Guardra Frontend

**Stack**: React 18, Vite, Tailwind CSS, vanilla `fetch` API client

### Tab-Based Routing (App.jsx)

| Tab ID | Component | Description |
|---|---|---|
| `dashboard` | `Dashboard.jsx` | Overview with quick stats, recent scans, live activity feed |
| `policy-analyzer` | `PolicyAnalyzer.jsx` | Domain input -> NLP analysis -> 6-pillar rubric display |
| `deletion-assistant` | `DeletionAssistant.jsx` | DPDP/GDPR/CCPA erasure request form, PDF download, tracking |
| `breach-monitor` | `BreachMonitor.jsx` | Password k-anonymity check, email exposure, domain breach radar |
| `control-hub` | `ControlHub.jsx` | Privacy footprint score, platform deep-links |
| `identity-wizard` | `IdentityWizard.jsx` | Identity architecture setup guide |
| `education-hub` | `EducationHub.jsx` | Privacy education modules |
| `regulators` | `Regulators.jsx` | Regulator escalation templates (DPBI, CNIL, ICO) |
| `admin-dashboard` | `AdminDashboard.jsx` | Website CRUD, cookie rules, ping analytics, top-5000 pipeline |

### API Client (`services/api.js`)
- Auto-detects local vs production (`localhost:8000` or `guardra-api.botvaibhav.dev`)
- `fetchWithFallback()` — tries local first (1.5s timeout), falls back to production, then offline mock data
- 28 exported API functions covering all backend endpoints

---

## 5. Guardra Extension

**Stack**: Vanilla JavaScript, Chrome Manifest V3 APIs

| File | World | Purpose |
|---|---|---|
| `background/service_worker.js` | Background | API polling, DNR rule management, state coordination, embedded offline database |
| `content/tracker_defuser.js` | MAIN | Intercepts tracking scripts before execution |
| `content/content_script.js` | Isolated | DOM scanning, cookie clearing, UI overlay injection |
| `content/yt_defuser.js` | MAIN | YouTube-specific tracker interception |
| `popup/popup.js` | Popup | Extension popup logic, scan triggers, DNR toggles |

**Permissions**: `activeTab`, `storage`, `tabs`, `alarms`, `cookies`, `declarativeNetRequest`, `<all_urls>`

---

## 6. Complete API Reference

### Policy Rating (`/api/policy`)
| Method | Path | Description |
|---|---|---|
| `GET` | `/api/policy/rating?domain=...` | Get privacy rating for a domain |
| `POST` | `/api/policy/analyze` | Analyze a URL directly |
| `GET` | `/api/policy/cached` | Get all cached policy ratings |

### Data Deletion (`/api/deletion`)
| Method | Path | Description |
|---|---|---|
| `POST` | `/api/deletion/generate-notice` | Generate erasure notice text + mailto |
| `POST` | `/api/deletion/generate-pdf` | Generate PDF erasure notice |
| `POST` | `/api/deletion/submit` | Submit and track a deletion request |
| `GET` | `/api/deletion/requests` | List all tracked deletion requests |
| `PATCH` | `/api/deletion/requests/{req_id}/status` | Update request status |
| `GET` | `/api/deletion/directory` | Get data broker directory |
| `GET` | `/api/deletion/regulators` | Get regulatory authorities |

### Breach Monitoring (`/api/breach`)
| Method | Path | Description |
|---|---|---|
| `POST` | `/api/breach/check-password` | K-anonymity HIBP password check |
| `POST` | `/api/breach/check-email` | Email breach exposure check |
| `GET` | `/api/breach/search?domain=...` | Domain breach OSINT search |

### Privacy Hub (`/api/hub`)
| Method | Path | Description |
|---|---|---|
| `GET` | `/api/hub/platforms` | Get privacy platform deep-links |
| `GET` | `/api/hub/footprint` | Get privacy footprint score |
| `POST` | `/api/hub/footprint/toggle` | Toggle footprint action |
| `POST` | `/api/hub/telemetry/active-session` | Record live telemetry |
| `GET` | `/api/hub/telemetry/live-feed` | Get live activity feed |
| `POST` | `/api/hub/scan-result` | Submit extension scan data |
| `POST` | `/api/hub/telemetry` | Record telemetry ping |
| `POST` | `/api/hub/telemetry/ping` | Record telemetry ping (alias) |
| `POST` | `/api/telemetry/ping` | Root telemetry ping |

### Admin Dashboard (`/api/admin`)
| Method | Path | Description |
|---|---|---|
| `POST` | `/api/admin/login` | Admin authentication |
| `GET` | `/api/admin/stats` | Dashboard statistics |
| `GET` | `/api/admin/sites` | List all sites (legacy format) |
| `POST` | `/api/admin/sites` | Add site (legacy) |
| `PUT` | `/api/admin/sites/{domain}` | Update site (legacy) |
| `GET` | `/api/admin/websites` | Paginated website list |
| `GET` | `/api/admin/websites/{domain}` | Website detail with cookies |
| `POST` | `/api/admin/websites` | Add + scan website |
| `POST` | `/api/admin/websites/{domain}/rescan` | Force rescan |
| `POST` | `/api/admin/websites/bulk-rescan` | Bulk rescan (background) |
| `DELETE` | `/api/admin/websites/{domain}` | Delete website + cookies |
| `GET` | `/api/admin/websites/{domain}/cookies` | Get website cookies + preferences |
| `PUT` | `/api/admin/websites/{domain}/cookies` | Bulk update cookie preferences |
| `GET` | `/api/admin/cookie-rules` | List global cookie rules |
| `POST` | `/api/admin/cookie-rules` | Create global cookie rule |
| `PUT` | `/api/admin/cookie-rules/{rule_id}` | Update cookie rule |
| `DELETE` | `/api/admin/cookie-rules/{rule_id}` | Delete cookie rule |
| `POST` | `/api/admin/top-5000/refresh` | Trigger top-5000 pipeline |
| `GET` | `/api/admin/top-5000/status` | Pipeline progress |
| `GET` | `/api/admin/pings` | Get telemetry pings |
| `GET` | `/api/admin/pings/stats` | Ping statistics |
| `GET` | `/api/admin/audit-log` | Paginated audit trail |
| `GET` | `/api/admin/analytics/visits` | Visit analytics (day/week/month) |
| `GET` | `/api/admin/crawler/status` | Crawler job status |
| `POST` | `/api/admin/crawler/rescore-site` | Rescore single site |
| `POST` | `/api/admin/crawler/rescore-all` | Bulk rescore (background) |
| `POST` | `/api/admin/crawler/scan-top-1000` | Scan top 1000 (background) |

### Root Endpoints
| Method | Path | Description |
|---|---|---|
| `GET` | `/` | Landing page (HTML) or service info (JSON) |
| `GET` | `/admin` | Admin portal HTML |
| `GET` | `/api/health` | Health check |
| `GET` | `/api/extension/download` | Download extension ZIP |
| `GET` | `/api/websites/{domain}/cookie-rules` | Cookie rules for extension |

---

## 7. Database Schema

SQLite database: `app/guardra.db` (or `/app/data/guardra.db` in Docker)

### `websites` — Primary domain analysis storage
| Column | Type | Description |
|---|---|---|
| `id` | INTEGER PK AUTO | Primary key |
| `domain` | TEXT UNIQUE NOT NULL | Cleaned domain (e.g. `google.com`) |
| `name` | TEXT | Display name |
| `category` | TEXT | Category (Web Service, E-Commerce, etc.) |
| `overall_score` | REAL | Composite privacy score (0-100) |
| `grade` | TEXT | Letter grade (A+ to F) |
| `grade_color` | TEXT | Hex color for UI |
| `pillar_scores` | TEXT (JSON) | 6-pillar rubric scores |
| `compliance` | TEXT (JSON) | DPDP/GDPR/CCPA compliance data |
| `findings` | TEXT (JSON) | Categorized policy findings |
| `key_concerns` | TEXT (JSON) | Privacy concern strings |
| `key_clauses` | TEXT (JSON) | Extracted policy clauses |
| `policy_text` | TEXT | Raw policy text (optional) |
| `policy_url` | TEXT | URL of the privacy policy |
| `cookie_data` | TEXT (JSON) | Detected cookies from extension |
| `tracker_data` | TEXT (JSON) | Detected trackers from extension |
| `dark_pattern_data` | TEXT (JSON) | Detected dark patterns |
| `breach_history` | TEXT (JSON) | Known breach records |
| `is_top_5000` | INTEGER DEFAULT 0 | Tranco top-5000 flag |
| `tranco_rank` | INTEGER | Tranco ranking position |
| `source` | TEXT DEFAULT 'manual' | Data source |
| `scan_count` | INTEGER DEFAULT 1 | Number of scans performed |
| `first_analyzed_at` | TEXT | ISO 8601 first scan timestamp |
| `last_analyzed_at` | TEXT | ISO 8601 last scan timestamp |
| `expires_at` | TEXT | Cache TTL (24h default) |
| `updated_at` | TEXT | Last modification timestamp |

### `deletion_requests` — Erasure request tracking
| Column | Type | Description |
|---|---|---|
| `id` | TEXT PK | Unique ID (e.g. `del_a1b2c3d4`) |
| `site_domain` | TEXT NOT NULL | Target domain |
| `site_name` | TEXT NOT NULL | Target site name |
| `legal_basis` | TEXT NOT NULL | `dpdp`, `gdpr`, or `ccpa` |
| `user_name` | TEXT NOT NULL | Requesting user's name |
| `user_email` | TEXT NOT NULL | Requesting user's email |
| `user_phone` | TEXT | Optional phone number |
| `account_identifier` | TEXT | Optional account ID |
| `grievance_email` | TEXT NOT NULL | Target's privacy email |
| `status` | TEXT DEFAULT 'Sent' | Sent/Acknowledged/In Progress/Resolved/Escalated |
| `created_at` | TEXT NOT NULL | Creation timestamp |
| `updated_at` | TEXT NOT NULL | Last update timestamp |
| `notes` | TEXT | Additional notes |
| `tracking_history` | TEXT (JSON) | Status change history array |

### `user_profile` — Privacy footprint state
| Column | Type | Description |
|---|---|---|
| `id` | TEXT PK | Profile ID (default: `'default'`) |
| `name` | TEXT | Display name |
| `email` | TEXT | User email |
| `footprint_score` | INTEGER DEFAULT 45 | Computed footprint score |
| `completed_actions` | TEXT DEFAULT '[]' | JSON array of completed action IDs |
| `created_at` | TEXT NOT NULL | Creation timestamp |

### `cookie_preferences` — Per-site cookie overrides
| Column | Type | Description |
|---|---|---|
| `id` | INTEGER PK AUTO | Primary key |
| `domain` | TEXT NOT NULL | Website domain |
| `cookie_name` | TEXT NOT NULL | Cookie name |
| `cookie_category` | TEXT | essential/analytics/advertising/social_media |
| `action` | TEXT DEFAULT 'block' | block/allow/ignore |
| `created_at` / `updated_at` | TEXT | Timestamps |
| — | UNIQUE(domain, cookie_name) | Composite unique constraint |

### `global_cookie_rules` — Default cookie taxonomy
| Column | Type | Description |
|---|---|---|
| `id` | INTEGER PK AUTO | Primary key |
| `cookie_pattern` | TEXT NOT NULL UNIQUE | Cookie name pattern |
| `cookie_category` | TEXT | Category classification |
| `default_action` | TEXT DEFAULT 'block' | Default action |
| `description` | TEXT | Human-readable description |
| `created_at` | TEXT | Creation timestamp |

### `browser_pings` — Extension telemetry
| Column | Type | Description |
|---|---|---|
| `id` | INTEGER PK AUTO | Primary key |
| `domain` | TEXT NOT NULL | Visited domain |
| `client_ip` | TEXT | Client IP address |
| `score` | REAL | Privacy score at visit time |
| `grade` | TEXT | Grade at visit time |
| `response_time_ms` | REAL | API response latency |
| `client_type` | TEXT | Client type (extension) |
| `timestamp` | TEXT NOT NULL | ISO 8601 visit timestamp |

### `admin_audit_log` — Admin action trail
| Column | Type | Description |
|---|---|---|
| `id` | INTEGER PK AUTO | Primary key |
| `action` | TEXT NOT NULL | Action type |
| `target` | TEXT | Target domain or entity |
| `details` | TEXT (JSON) | Additional action details |
| `performed_at` | TEXT | ISO 8601 timestamp |

---

## 8. Scoring Engine (6-Pillar Rubric)

| Pillar | Weight | Measures |
|---|---|---|
| P1: Third-Party Data Sharing | 20% | Data selling, broker relationships, ad networks |
| P2: Cookies and Telemetry | 40% | Tracking pixels, fingerprinting, real extension data |
| P3: User Rights and Erasure | 15% | Deletion rights, opt-out, grievance officers |
| P4: Data Retention | 10% | Retention periods, auto-purge policies |
| P5: Breach History | 8% | Known breaches, security safeguards |
| P6: Readability | 7% | Flesch Reading Ease score |

### Grade Bands
| Score | Grade | Color |
|---|---|---|
| 92-100 | A+ | Green |
| 83-91 | A | Green |
| 74-82 | B+ | Light Green |
| 65-73 | B | Light Green |
| 55-64 | C+ | Amber |
| 45-54 | C | Amber |
| 35-44 | D+ | Orange |
| 25-34 | D | Orange |
| 0-24 | F | Red |

### Key Features
- **Negation-aware matching**: "We do NOT sell data" is a positive signal
- **Real tracker integration**: 75% real data + 25% policy text when extension data available
- **Compliance bonuses**: +3 for verified DPDP Grievance Officer, +3 for GDPR DPO
- **Breach penalties**: -30 for 1M+ record breaches
- **Dark pattern penalties**: -3 per pattern (max -15)

---

## 9. Data Files (`app/data/`)

| File | Description |
|---|---|
| `cached_policies.json` | Pre-scored website privacy evaluations (40+ sites) |
| `data_brokers.json` | Data broker directory with opt-out URLs |
| `privacy_hub.json` | Platform-specific privacy control deep-links |
| `regulators.json` | Data Protection Authority contacts (DPBI, CNIL, ICO) |
| `top_1000_domains.json` | Top domains for scheduled crawler |

---

## 10. Environment Variables

| Variable | Default | Description |
|---|---|---|
| `ENVIRONMENT` | `production` | Deployment environment |
| `SERVER_PORT` | `8756` | API server port |
| `HOST` | `0.0.0.0` | Binding address |
| `ALLOWED_ORIGINS` | `*` | CORS allowed origins |
| `ADMIN_SECRET_KEY` | `guardra_admin_secret_2026` | Admin portal authentication key |
| `LOG_LEVEL` | `info` | Python logging level |
| `DATABASE_PATH` | — | Override SQLite database path |
| `GUARDRA_DATA_DIR` | — | Override data directory |

---

## 11. Setup and Development

### Quick Start
```bash
./run_demo.sh   # Starts backend (port 8000) + frontend (port 5173)
```

### Manual Setup
```bash
# Backend
cd Guardra-Server && pip install -r requirements.txt && uvicorn app.main:app --reload

# Frontend
cd Guardra/frontend && npm install && npm run dev

# Extension: Chrome > chrome://extensions > Load unpacked > select extension/
```

### Key URLs
- API: `http://localhost:8000` | Docs: `http://localhost:8000/docs`
- Admin: `http://localhost:8000/admin` | Frontend: `http://localhost:5173`

---

## 12. Deployment (Docker)

```bash
cd Guardra-Server && docker-compose up -d --build
```

- Persistent volume `guardra-data` at `/app/data`
- Resource limits: 1 CPU / 2GB RAM
- Health check: `curl -f http://localhost:8000/api/health` every 30s
- Production: Rotate `ADMIN_SECRET_KEY`, use Nginx/Traefik with TLS

---

## 13. Python Dependencies

| Package | Version | Purpose |
|---|---|---|
| `fastapi` | >=0.115.0 | Web framework |
| `uvicorn[standard]` | >=0.32.0 | ASGI server |
| `pydantic` | >=2.9.0 | Data validation |
| `httpx` | >=0.28.0 | Async HTTP client |
| `beautifulsoup4` | >=4.12.0 | HTML parsing |
| `reportlab` | >=4.2.0 | PDF generation |
| `python-multipart` | >=0.0.12 | Form data parsing |
